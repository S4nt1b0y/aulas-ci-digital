1784936419 /home/cidigital/projects/aulas-ci-digital/aula_24_07/LAB01/design_syn.v
1784937675 /home/cidigital/projects/aulas-ci-digital/aula_24_07/LAB01/counter_tb.v
1709902420 /home/cidigital/projects/aulas-ci-digital/aula_24_07/LIB/fast_vdd1v0_basicCells.v
